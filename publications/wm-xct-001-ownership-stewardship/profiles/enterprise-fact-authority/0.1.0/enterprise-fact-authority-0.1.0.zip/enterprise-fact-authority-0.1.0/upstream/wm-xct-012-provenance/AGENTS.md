# Provenance

- Name: Provenance
- Catalogue ID: WM-XCT-012
- Registry ID: vr.wm-xct-012
- Type: Published Vercy mixin
- Version: 0.3.0-research.1
- Specification: https://ver.cy/models/wm-xct-012-provenance/spec.yaml
- Storage type: format-independent; select a binding in the page constructor
- Interface: https://ver.cy/models/wm-xct-012-provenance/#template-builder
- Processes: https://ver.cy/processes/
- Research evidence: https://github.com/ver-cy/world-models/tree/feat/mega-model-registry/research/runs/wm-xct-012

Read this file first, then `spec.yaml`. Traverse Bundle → Layer → Finding →
Questions and Artifacts. The specification is published, while its research
assurance remains `reviewable-draft`. Do not claim canonical completeness
while `researchAdjudication.publicationHolds` is non-empty. Preserve source
references, master-system identity and access rules.
